sap.ui.define([
	"IP/ISYSTEM_PORTAL/test/unit/controller/Login.controller"
], function () {
	"use strict";
});